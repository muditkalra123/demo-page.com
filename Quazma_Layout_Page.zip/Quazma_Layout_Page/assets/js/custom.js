(function($){
    "use strict";
      
    // Ready Function
    jQuery(document).ready(function($){
        var $this = $(window);

      

    });
      
})();